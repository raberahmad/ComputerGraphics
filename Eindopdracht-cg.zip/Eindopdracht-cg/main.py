import pygame as pygame
from pygame.locals import *
import random
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from PIL import Image
import numpy

"""
Raber Ahmad 0921954



massieve 3d vormen  (kubus en sphere)
gebruiksinteractie (animatie handmatig bedienen, starten stoppen, volgend object)
perspectief ()
animatie (autoamtische animatie)
belichting (gebruikt gemaakt van een lichtbron)
texturemapping (earth and mars)
shading (colored the cube)
clipping (min and max distance of object)
3d tranfomaties (rotatie, translatie, scaling)
"""



surfaces = ("cube", "world.jpg", "mars.png", "jupiter.jpg")


vertices = ((1, 1, 1),
            (1, 1, -1),
            (1, -1, -1),
            (1, -1, 1),
            (-1, 1, 1),
            (-1, -1, -1),
            (-1, -1, 1),
            (-1, 1, -1))


# the 12 edges of the cube
line_connections = ((0, 1), (0, 3), (0, 4),
                    (1, 2), (1, 7), (2, 5),
                    (2, 3), (3, 6), (4, 6),
                    (4, 7), (5, 6), (5, 7),)


# the 6 surfaces of the cube
cube_sides = ((0, 3, 6, 4), (2, 5, 6, 3), (1, 2, 5, 7), 
                (1, 0, 4, 7), (7, 4, 6, 5), (2, 3, 0, 1),)


colors = ((1, 1, 1),   (1, 1, 0),   (1, 0, 0),   (1, 0, 1),  
     (1, 1, 1),   (1, 0, 1),   (0, 0, 1),   (0, 1, 1),  
     (1, 1, 1),   (0, 1, 1),   (0, 1, 0),   (1, 1, 0),  
     (1, 1, 0),   (0, 1, 0),   (0, 0, 0),   (1, 0, 0),  
     (0, 0, 0),   (0, 0, 1),   (1, 0, 1),   (1, 0, 0),  
     (0, 0, 1),   (0, 0, 0),   (0, 1, 0),   (0, 1, 1)) 

def load_texture(filename):
    img = Image.open(filename)  #read the image
    img_data = numpy.array(list(img.getdata()), numpy.int8) #convert the image to numpy array
    texture_id = glGenTextures(1) #create texture id
    glBindTexture(GL_TEXTURE_2D, texture_id)
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB,
                 img.size[0], img.size[1], 0, GL_RGB, GL_UNSIGNED_BYTE, img_data)
    return texture_id

def cubeGL():
    glBegin(GL_QUADS)
    for side in cube_sides:
        color_index = 0
      
        for vertex in side:
            color_index += 3
            glColor3fv(colors[color_index])
            glVertex3fv(vertices[vertex])
    glEnd()

def pyrGL():
    glBegin(GL_QUADS)
    for surface in surfaces_pyr:
        color_index = 0
        
        for vertex in surface:
            color_index += 3
            glColor3fv(colors[color_index])
            glVertex3fv(verticies_pyr[vertex])
    glEnd()

def main():

    #pygame init en display dimensies
    pygame.init()
    display = (800, 600)

    #using opengl in pygame and setting windowsize
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    pygame.key.set_repeat(200, 10) #allowing for repeating keys

    gluPerspective(45, (display[0]/display[1]), 2, 25.0)
    glMatrixMode(GL_MODELVIEW)

    glLightfv(GL_LIGHT0, GL_POSITION,  (5, 5, 5, 1)) 
    glLightfv(GL_LIGHT0, GL_AMBIENT, (0, 0, 0, 1))
    glLightfv(GL_LIGHT0, GL_DIFFUSE, (1, 1, 1, 1))
   

    glTranslatef(0.0, 0.0, -5)
    animate = False
    
    index = 0
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT: # rotate to left
                    glRotatef(1, 0, -1, 0)
                if event.key == pygame.K_RIGHT: # rotate to right
                    glRotatef(1, 0, 1, 0)
                if event.key == pygame.K_UP: # rotate up
                    glRotatef(1, 1, 0, 0)
                if event.key == pygame.K_DOWN: # rotate down
                    glRotatef(1, -1, 0, 0)


                if event.key == pygame.K_w: # translate up
                    glTranslatef(0.0, 0.1, 0.0)
                if event.key == pygame.K_s:
                    glTranslatef(0.0,  -0.1, 0.0) # translate down
                if event.key == pygame.K_a:
                     glTranslatef(-0.1, 0.0, 0.0) # translate left
                if event.key == pygame.K_d:
                    glTranslatef(0.1, 0.0, 0.0) # translate right


                
                if event.key == pygame.K_SPACE: #switch between auto animation
                    if animate == False:
                        animate = True
                    else:
                        animate = False


            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 4:  # wheel roll in to zoom in 
                    glScaled(1.05, 1.05, 1.05)
                if event.button == 5:  # wheel roll out to zoom out
                    glScaled(0.95, 0.95, 0.95)

                if event.button == 1:  # left mouse click to load the next texture
                    if index == len(surfaces)-1:
                        index = 0
                    else:
                        index +=1
                    if index != 0 :
                        pygame.display.flip()
                        texture = load_texture('surfaces/'+surfaces[index])
                if event.button == 3:  # right mouse click to load the previous texture
                    if index == 0:
                        index = len(surfaces)-1
                    else:
                        index-=1
                    if index != 0 :
                        pygame.display.flip()
                        texture = load_texture('surfaces/'+surfaces[index])
                    
        

        if animate == True:
            glRotatef(1, 0, 1, 0)


        glEnable(GL_DEPTH_TEST)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)


        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)
        
        
        if index == 0:
            cubeGL()
        else:
            qobj = gluNewQuadric()
            gluQuadricTexture(qobj, GL_TRUE)
            glEnable(GL_TEXTURE_2D)
            glBindTexture(GL_TEXTURE_2D, texture)
            gluSphere(qobj, 1, 50, 50)
            gluDeleteQuadric(qobj)
            glDisable(GL_TEXTURE_2D)

        glDisable(GL_LIGHT0)
        glDisable(GL_LIGHTING)
        glDisable(GL_COLOR_MATERIAL)
    
        



        pygame.display.flip()
        pygame.time.wait(10)



if __name__ == "__main__":
    main()       